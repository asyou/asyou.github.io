import Vue from "vue"
const platform = uni.getSystemInfoSync().platform
const clientid = plus.push.getClientInfo()['clientid']
export default {
	getServerNo: (version, isPrompt = false, callback) => {
		/**
		 * 请求参数
		 * versionCode: 应用当前版本号（已自动获取）
		 * versionName: 应用当前版本名称（已自动获取）
		 * setupPage: 是否主动更新（true|false）
		 * type：平台类型（1=用户端|2=商家端）
		 * platform: 终端类型（1=android|2=ios）
		 * clientid: 终端ID
		 * 返回数据
		 * | 参数名称			| 必须返回	| 类型		| 描述
		 * | -------------- | --------- | --------- | ------------- |
		 * | versionCode	| y			| int		| 版本号			|
		 * | versionName	| y			| String	| 版本名称		|
		 * | versionInfo	| y			| String	| 版本信息		|
		 * | updateType		| y			| String	| forcibly=强制更新, solicit=弹窗确认更新, silent=静默更新 |
		 * | downloadUrl	| y			| String	| 版本下载链接（IOS安装包更新放store应用商店链接,安卓apk和wgt文件放文件下载链接）|
		 */
		Vue.prototype.$http.post("index/checkUpgrade", {
			versionCode: version.versionCode,
			versionName: version.versionName,
			setupPage: isPrompt,
			type: 1,
			platform: platform == 'android' ? 1 : 2,
			clientid: clientid
		}).then(res => {
			if (res.data.info && res.data.info.downloadUrl) {
				callback && callback(res.data.info)
			} else if (isPrompt) {
				uni.showToast({
					title: "暂无新版本",
					icon: "none"
				})
			}
		})
	},
	// 弹窗主颜色（不填默认粉色）
	appUpdateColor: "f00",
	// 弹窗图标（不填显示默认图标，链接配置示例如： '/static/ic_ar.png'）
	appUpdateIcon: ''
}
